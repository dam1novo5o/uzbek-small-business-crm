export interface Customer {
  id: string
  name: string
  phone: string
  email?: string
  company?: string
  address?: string
  notes?: string
  totalPurchases: number
  lastPurchase?: string
  createdAt: string
}

export interface Sale {
  id: string
  customerId: string
  customerName: string
  amount: number
  description: string
  status: "pending" | "completed" | "cancelled"
  date: string
}

export interface DashboardStats {
  totalCustomers: number
  totalSales: number
  totalRevenue: number
  recentSales: Sale[]
  topCustomers: Customer[]
}
