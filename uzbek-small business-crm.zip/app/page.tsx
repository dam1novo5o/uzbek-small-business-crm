import { Sidebar } from "@/components/sidebar"
import { StatsCard } from "@/components/stats-card"
import { RecentSales } from "@/components/recent-sales"
import { TopCustomers } from "@/components/top-customers"
import { dashboardStats } from "@/lib/mock-data"
import { Users, ShoppingCart, DollarSign, TrendingUp } from "lucide-react"

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("uz-UZ").format(amount) + " so'm"
}

export default function DashboardPage() {
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />

      <main className="flex-1 md:ml-64">
        <div className="border-b border-border bg-card px-6 py-4 md:px-8">
          <h1 className="text-xl font-semibold text-card-foreground md:text-2xl">Bosh sahifa</h1>
          <p className="text-sm text-muted-foreground">Biznesingiz haqida umumiy ma'lumot</p>
        </div>

        <div className="p-6 md:p-8">
          {/* Stats Grid */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatsCard
              title="Jami mijozlar"
              value={dashboardStats.totalCustomers.toString()}
              description="Faol mijozlar soni"
              icon={Users}
              trend={{ value: 12, isPositive: true }}
            />
            <StatsCard
              title="Jami sotuvlar"
              value={dashboardStats.totalSales.toString()}
              description="Shu oydagi sotuvlar"
              icon={ShoppingCart}
              trend={{ value: 8, isPositive: true }}
            />
            <StatsCard
              title="Jami daromad"
              value={formatCurrency(dashboardStats.totalRevenue)}
              description="Shu oydagi daromad"
              icon={DollarSign}
              trend={{ value: 15, isPositive: true }}
            />
            <StatsCard
              title="O'rtacha sotuv"
              value={formatCurrency(Math.round(dashboardStats.totalRevenue / dashboardStats.totalSales))}
              description="Har bir sotuv uchun"
              icon={TrendingUp}
              trend={{ value: 5, isPositive: true }}
            />
          </div>

          {/* Recent Sales & Top Customers */}
          <div className="mt-8 grid gap-6 lg:grid-cols-2">
            <RecentSales sales={dashboardStats.recentSales} />
            <TopCustomers customers={dashboardStats.topCustomers} />
          </div>
        </div>
      </main>
    </div>
  )
}
