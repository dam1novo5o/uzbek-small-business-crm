"use client"

import { useState } from "react"
import { Sidebar } from "@/components/sidebar"
import { SalesTable } from "@/components/sales-table"
import { SaleForm } from "@/components/sale-form"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { sales as initialSales, customers } from "@/lib/mock-data"
import type { Sale } from "@/lib/types"
import { Plus, Search, TrendingUp, Clock, CheckCircle } from "lucide-react"

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("uz-UZ").format(amount) + " so'm"
}

export default function SalesPage() {
  const [sales, setSales] = useState<Sale[]>(initialSales)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [formOpen, setFormOpen] = useState(false)
  const [editingSale, setEditingSale] = useState<Sale | null>(null)

  const filteredSales = sales.filter((sale) => {
    const matchesSearch =
      sale.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sale.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesStatus = statusFilter === "all" || sale.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const totalRevenue = sales.filter((s) => s.status === "completed").reduce((sum, s) => sum + s.amount, 0)
  const pendingSales = sales.filter((s) => s.status === "pending")
  const pendingAmount = pendingSales.reduce((sum, s) => sum + s.amount, 0)
  const completedCount = sales.filter((s) => s.status === "completed").length

  const handleSave = (saleData: Partial<Sale>) => {
    if (editingSale) {
      setSales(sales.map((s) => (s.id === editingSale.id ? { ...s, ...saleData } : s)))
    } else {
      setSales([saleData as Sale, ...sales])
    }
    setEditingSale(null)
  }

  const handleEdit = (sale: Sale) => {
    setEditingSale(sale)
    setFormOpen(true)
  }

  const handleDelete = (saleId: string) => {
    setSales(sales.filter((s) => s.id !== saleId))
  }

  const handleStatusChange = (saleId: string, status: Sale["status"]) => {
    setSales(sales.map((s) => (s.id === saleId ? { ...s, status } : s)))
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />

      <main className="flex-1 md:ml-64">
        <div className="border-b border-border bg-card px-6 py-4 md:px-8">
          <h1 className="text-xl font-semibold text-card-foreground md:text-2xl">Sotuvlar</h1>
          <p className="text-sm text-muted-foreground">Barcha sotuvlaringizni kuzating</p>
        </div>

        <div className="p-6 md:p-8">
          {/* Stats */}
          <div className="mb-6 grid gap-4 sm:grid-cols-3">
            <div className="rounded-lg border border-border bg-card p-4">
              <div className="flex items-center gap-3">
                <div className="rounded-lg bg-chart-1/10 p-2">
                  <TrendingUp className="h-5 w-5 text-chart-1" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Jami daromad</p>
                  <p className="text-xl font-bold text-card-foreground">{formatCurrency(totalRevenue)}</p>
                </div>
              </div>
            </div>
            <div className="rounded-lg border border-border bg-card p-4">
              <div className="flex items-center gap-3">
                <div className="rounded-lg bg-chart-4/10 p-2">
                  <Clock className="h-5 w-5 text-chart-4" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Kutilayotgan ({pendingSales.length})</p>
                  <p className="text-xl font-bold text-card-foreground">{formatCurrency(pendingAmount)}</p>
                </div>
              </div>
            </div>
            <div className="rounded-lg border border-border bg-card p-4">
              <div className="flex items-center gap-3">
                <div className="rounded-lg bg-primary/10 p-2">
                  <CheckCircle className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Yakunlangan sotuvlar</p>
                  <p className="text-xl font-bold text-card-foreground">{completedCount}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Actions Bar */}
          <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Sotuvlarni qidirish..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-40">
                  <SelectValue placeholder="Holati" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Barchasi</SelectItem>
                  <SelectItem value="completed">Yakunlangan</SelectItem>
                  <SelectItem value="pending">Kutilmoqda</SelectItem>
                  <SelectItem value="cancelled">Bekor qilingan</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button
              onClick={() => {
                setEditingSale(null)
                setFormOpen(true)
              }}
            >
              <Plus className="mr-2 h-4 w-4" />
              Yangi sotuv
            </Button>
          </div>

          {/* Sales Table */}
          {filteredSales.length > 0 ? (
            <SalesTable
              sales={filteredSales}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onStatusChange={handleStatusChange}
            />
          ) : (
            <div className="rounded-lg border border-border bg-card p-12 text-center">
              <p className="text-muted-foreground">
                {searchQuery || statusFilter !== "all" ? "Hech qanday sotuv topilmadi" : "Hali sotuvlar yo'q"}
              </p>
              {!searchQuery && statusFilter === "all" && (
                <Button
                  className="mt-4"
                  onClick={() => {
                    setEditingSale(null)
                    setFormOpen(true)
                  }}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Birinchi sotuvni qo'shing
                </Button>
              )}
            </div>
          )}
        </div>
      </main>

      <SaleForm
        open={formOpen}
        onOpenChange={setFormOpen}
        sale={editingSale}
        customers={customers}
        onSave={handleSave}
      />
    </div>
  )
}
