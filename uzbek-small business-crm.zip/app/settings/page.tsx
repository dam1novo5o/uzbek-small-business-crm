"use client"

import type React from "react"

import { useState } from "react"
import { Sidebar } from "@/components/sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Building2, Mail, Phone, MapPin, Bell, Moon, Globe } from "lucide-react"

export default function SettingsPage() {
  const [businessInfo, setBusinessInfo] = useState({
    name: "Mening biznesim",
    email: "biznes@example.com",
    phone: "+998 90 123 45 67",
    address: "Toshkent shahri",
    description: "",
  })

  const [notifications, setNotifications] = useState({
    newSale: true,
    newCustomer: true,
    salesReport: false,
  })

  const [darkMode, setDarkMode] = useState(false)

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real app, this would save to a database
    alert("Ma'lumotlar saqlandi!")
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />

      <main className="flex-1 md:ml-64">
        <div className="border-b border-border bg-card px-6 py-4 md:px-8">
          <h1 className="text-xl font-semibold text-card-foreground md:text-2xl">Sozlamalar</h1>
          <p className="text-sm text-muted-foreground">Biznes profilingizni va ilovangizni sozlang</p>
        </div>

        <div className="p-6 md:p-8">
          <div className="mx-auto max-w-3xl space-y-6">
            {/* Profile Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-primary" />
                  Biznes ma'lumotlari
                </CardTitle>
                <CardDescription>Biznesingiz haqidagi asosiy ma'lumotlar</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSaveProfile} className="space-y-4">
                  <div className="flex items-center gap-4">
                    <Avatar className="h-16 w-16">
                      <AvatarFallback className="bg-primary text-lg text-primary-foreground">
                        {businessInfo.name.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-foreground">{businessInfo.name}</p>
                      <p className="text-sm text-muted-foreground">Biznes profili</p>
                    </div>
                  </div>

                  <div className="grid gap-4 pt-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="businessName">Biznes nomi</Label>
                      <div className="relative">
                        <Building2 className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                        <Input
                          id="businessName"
                          value={businessInfo.name}
                          onChange={(e) => setBusinessInfo({ ...businessInfo, name: e.target.value })}
                          className="pl-9"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                        <Input
                          id="email"
                          type="email"
                          value={businessInfo.email}
                          onChange={(e) => setBusinessInfo({ ...businessInfo, email: e.target.value })}
                          className="pl-9"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Telefon</Label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                        <Input
                          id="phone"
                          value={businessInfo.phone}
                          onChange={(e) => setBusinessInfo({ ...businessInfo, phone: e.target.value })}
                          className="pl-9"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="address">Manzil</Label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                        <Input
                          id="address"
                          value={businessInfo.address}
                          onChange={(e) => setBusinessInfo({ ...businessInfo, address: e.target.value })}
                          className="pl-9"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Biznes tavsifi</Label>
                    <Textarea
                      id="description"
                      value={businessInfo.description}
                      onChange={(e) => setBusinessInfo({ ...businessInfo, description: e.target.value })}
                      placeholder="Biznesingiz haqida qisqacha..."
                      rows={3}
                    />
                  </div>

                  <div className="flex justify-end pt-2">
                    <Button type="submit">Ma'lumotlarni saqlash</Button>
                  </div>
                </form>
              </CardContent>
            </Card>

            {/* Notifications Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="h-5 w-5 text-primary" />
                  Bildirishnomalar
                </CardTitle>
                <CardDescription>Qachon bildirishnoma olishni tanlang</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between rounded-lg border border-border p-4">
                  <div className="space-y-0.5">
                    <p className="font-medium text-foreground">Yangi sotuv</p>
                    <p className="text-sm text-muted-foreground">Yangi sotuv qo'shilganda bildirishnoma oling</p>
                  </div>
                  <Switch
                    checked={notifications.newSale}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, newSale: checked })}
                  />
                </div>
                <div className="flex items-center justify-between rounded-lg border border-border p-4">
                  <div className="space-y-0.5">
                    <p className="font-medium text-foreground">Yangi mijoz</p>
                    <p className="text-sm text-muted-foreground">Yangi mijoz qo'shilganda bildirishnoma oling</p>
                  </div>
                  <Switch
                    checked={notifications.newCustomer}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, newCustomer: checked })}
                  />
                </div>
                <div className="flex items-center justify-between rounded-lg border border-border p-4">
                  <div className="space-y-0.5">
                    <p className="font-medium text-foreground">Haftalik hisobot</p>
                    <p className="text-sm text-muted-foreground">Har hafta sotuvlar haqida hisobot oling</p>
                  </div>
                  <Switch
                    checked={notifications.salesReport}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, salesReport: checked })}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Appearance Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Moon className="h-5 w-5 text-primary" />
                  Ko'rinish
                </CardTitle>
                <CardDescription>Ilovaning ko'rinishini sozlang</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between rounded-lg border border-border p-4">
                  <div className="space-y-0.5">
                    <p className="font-medium text-foreground">Tungi rejim</p>
                    <p className="text-sm text-muted-foreground">Qorong'i fon rangini yoqing</p>
                  </div>
                  <Switch
                    checked={darkMode}
                    onCheckedChange={(checked) => {
                      setDarkMode(checked)
                      document.documentElement.classList.toggle("dark", checked)
                    }}
                  />
                </div>
                <div className="flex items-center justify-between rounded-lg border border-border p-4">
                  <div className="flex items-center gap-3">
                    <Globe className="h-5 w-5 text-muted-foreground" />
                    <div className="space-y-0.5">
                      <p className="font-medium text-foreground">Til</p>
                      <p className="text-sm text-muted-foreground">Ilova tili</p>
                    </div>
                  </div>
                  <span className="text-sm font-medium text-primary">O'zbekcha</span>
                </div>
              </CardContent>
            </Card>

            {/* About Section */}
            <Card>
              <CardContent className="py-6">
                <div className="text-center">
                  <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-primary">
                    <span className="text-lg font-bold text-primary-foreground">B</span>
                  </div>
                  <h3 className="font-semibold text-foreground">BiznesCRM</h3>
                  <p className="mt-1 text-sm text-muted-foreground">Kichik biznes uchun oddiy CRM</p>
                  <p className="mt-2 text-xs text-muted-foreground">Versiya 1.0.0</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
