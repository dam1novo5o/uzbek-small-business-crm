"use client"

import { useState } from "react"
import { Sidebar } from "@/components/sidebar"
import { CustomerTable } from "@/components/customer-table"
import { CustomerForm } from "@/components/customer-form"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { customers as initialCustomers } from "@/lib/mock-data"
import type { Customer } from "@/lib/types"
import { Plus, Search } from "lucide-react"

export default function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>(initialCustomers)
  const [searchQuery, setSearchQuery] = useState("")
  const [formOpen, setFormOpen] = useState(false)
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null)

  const filteredCustomers = customers.filter(
    (customer) =>
      customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      customer.phone.includes(searchQuery) ||
      customer.company?.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleSave = (customerData: Partial<Customer>) => {
    if (editingCustomer) {
      setCustomers(customers.map((c) => (c.id === editingCustomer.id ? { ...c, ...customerData } : c)))
    } else {
      setCustomers([...customers, customerData as Customer])
    }
    setEditingCustomer(null)
  }

  const handleEdit = (customer: Customer) => {
    setEditingCustomer(customer)
    setFormOpen(true)
  }

  const handleDelete = (customerId: string) => {
    setCustomers(customers.filter((c) => c.id !== customerId))
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />

      <main className="flex-1 md:ml-64">
        <div className="border-b border-border bg-card px-6 py-4 md:px-8">
          <h1 className="text-xl font-semibold text-card-foreground md:text-2xl">Mijozlar</h1>
          <p className="text-sm text-muted-foreground">Barcha mijozlaringizni boshqaring</p>
        </div>

        <div className="p-6 md:p-8">
          {/* Actions Bar */}
          <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="relative w-full sm:max-w-xs">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Mijozlarni qidirish..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Button
              onClick={() => {
                setEditingCustomer(null)
                setFormOpen(true)
              }}
            >
              <Plus className="mr-2 h-4 w-4" />
              Yangi mijoz
            </Button>
          </div>

          {/* Customer Stats */}
          <div className="mb-6 grid gap-4 sm:grid-cols-3">
            <div className="rounded-lg border border-border bg-card p-4">
              <p className="text-sm text-muted-foreground">Jami mijozlar</p>
              <p className="mt-1 text-2xl font-bold text-card-foreground">{customers.length}</p>
            </div>
            <div className="rounded-lg border border-border bg-card p-4">
              <p className="text-sm text-muted-foreground">Yangi mijozlar (shu oy)</p>
              <p className="mt-1 text-2xl font-bold text-card-foreground">
                {
                  customers.filter((c) => c.createdAt?.startsWith("2024-11") || c.createdAt?.startsWith("2024-12"))
                    .length
                }
              </p>
            </div>
            <div className="rounded-lg border border-border bg-card p-4">
              <p className="text-sm text-muted-foreground">Kompaniyalar</p>
              <p className="mt-1 text-2xl font-bold text-card-foreground">
                {customers.filter((c) => c.company).length}
              </p>
            </div>
          </div>

          {/* Customer Table */}
          {filteredCustomers.length > 0 ? (
            <CustomerTable customers={filteredCustomers} onEdit={handleEdit} onDelete={handleDelete} />
          ) : (
            <div className="rounded-lg border border-border bg-card p-12 text-center">
              <p className="text-muted-foreground">
                {searchQuery ? "Hech qanday mijoz topilmadi" : "Hali mijozlar yo'q"}
              </p>
              {!searchQuery && (
                <Button
                  className="mt-4"
                  onClick={() => {
                    setEditingCustomer(null)
                    setFormOpen(true)
                  }}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Birinchi mijozni qo'shing
                </Button>
              )}
            </div>
          )}
        </div>
      </main>

      <CustomerForm open={formOpen} onOpenChange={setFormOpen} customer={editingCustomer} onSave={handleSave} />
    </div>
  )
}
