import type React from "react"
import type { Metadata } from "next"

import { Analytics } from "@vercel/analytics/next"
import "./globals.css"
import { Inter, Geist_Mono, Comfortaa as V0_Font_Comfortaa, Geist_Mono as V0_Font_Geist_Mono } from 'next/font/google'

// Initialize fonts
const _comfortaa = V0_Font_Comfortaa({ subsets: ['latin'], weight: ["300","400","500","600","700"] })
const _geistMono = V0_Font_Geist_Mono({ subsets: ['latin'], weight: ["100","200","300","400","500","600","700","800","900"] })

const _inter = Inter({ subsets: ["latin", "cyrillic"] })
export const metadata: Metadata = {
  title: "BiznesCRM - Kichik Biznes Uchun",
  description: "Kichik biznes egalari uchun oddiy va arzon mijozlar boshqaruvi dasturi",
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html className="opacity-100" lang="uz">
      <body className={`font-sans antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
