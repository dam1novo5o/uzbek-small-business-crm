"use client"

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { MoreHorizontal, Pencil, Trash2, CheckCircle, XCircle, Clock } from "lucide-react"
import type { Sale } from "@/lib/types"

interface SalesTableProps {
  sales: Sale[]
  onEdit: (sale: Sale) => void
  onDelete: (saleId: string) => void
  onStatusChange: (saleId: string, status: Sale["status"]) => void
}

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("uz-UZ").format(amount) + " so'm"
}

function getStatusBadge(status: Sale["status"]) {
  switch (status) {
    case "completed":
      return (
        <Badge className="bg-chart-1/10 text-chart-1 hover:bg-chart-1/20">
          <CheckCircle className="mr-1 h-3 w-3" />
          Yakunlangan
        </Badge>
      )
    case "pending":
      return (
        <Badge className="bg-chart-4/10 text-chart-4 hover:bg-chart-4/20">
          <Clock className="mr-1 h-3 w-3" />
          Kutilmoqda
        </Badge>
      )
    case "cancelled":
      return (
        <Badge variant="destructive" className="bg-destructive/10 text-destructive">
          <XCircle className="mr-1 h-3 w-3" />
          Bekor qilingan
        </Badge>
      )
    default:
      return null
  }
}

export function SalesTable({ sales, onEdit, onDelete, onStatusChange }: SalesTableProps) {
  return (
    <div className="rounded-lg border border-border">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead className="font-semibold">Sana</TableHead>
            <TableHead className="font-semibold">Mijoz</TableHead>
            <TableHead className="font-semibold">Tavsif</TableHead>
            <TableHead className="font-semibold">Summa</TableHead>
            <TableHead className="font-semibold">Holati</TableHead>
            <TableHead className="w-[50px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sales.map((sale) => (
            <TableRow key={sale.id} className="hover:bg-muted/30">
              <TableCell>
                <span className="text-sm text-foreground">{sale.date}</span>
              </TableCell>
              <TableCell>
                <span className="font-medium text-foreground">{sale.customerName}</span>
              </TableCell>
              <TableCell>
                <span className="text-sm text-muted-foreground">{sale.description}</span>
              </TableCell>
              <TableCell>
                <span className="text-sm font-semibold text-foreground">{formatCurrency(sale.amount)}</span>
              </TableCell>
              <TableCell>{getStatusBadge(sale.status)}</TableCell>
              <TableCell>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => onEdit(sale)}>
                      <Pencil className="mr-2 h-4 w-4" />
                      Tahrirlash
                    </DropdownMenuItem>
                    {sale.status === "pending" && (
                      <DropdownMenuItem onClick={() => onStatusChange(sale.id, "completed")}>
                        <CheckCircle className="mr-2 h-4 w-4" />
                        Yakunlash
                      </DropdownMenuItem>
                    )}
                    {sale.status === "pending" && (
                      <DropdownMenuItem onClick={() => onStatusChange(sale.id, "cancelled")}>
                        <XCircle className="mr-2 h-4 w-4" />
                        Bekor qilish
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem onClick={() => onDelete(sale.id)} className="text-destructive">
                      <Trash2 className="mr-2 h-4 w-4" />
                      O'chirish
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
