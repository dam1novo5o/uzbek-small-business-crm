import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Sale } from "@/lib/types"

interface RecentSalesProps {
  sales: Sale[]
}

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("uz-UZ").format(amount) + " so'm"
}

function getStatusBadge(status: Sale["status"]) {
  switch (status) {
    case "completed":
      return <Badge className="bg-chart-1/10 text-chart-1 hover:bg-chart-1/20">Yakunlangan</Badge>
    case "pending":
      return <Badge className="bg-chart-4/10 text-chart-4 hover:bg-chart-4/20">Kutilmoqda</Badge>
    case "cancelled":
      return <Badge variant="destructive">Bekor qilingan</Badge>
    default:
      return null
  }
}

export function RecentSales({ sales }: RecentSalesProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold">So'nggi sotuvlar</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {sales.map((sale) => (
            <div key={sale.id} className="flex items-center justify-between rounded-lg border border-border p-4">
              <div className="space-y-1">
                <p className="text-sm font-medium text-card-foreground">{sale.customerName}</p>
                <p className="text-xs text-muted-foreground">{sale.description}</p>
                <p className="text-xs text-muted-foreground">{sale.date}</p>
              </div>
              <div className="flex flex-col items-end gap-2">
                <p className="text-sm font-semibold text-card-foreground">{formatCurrency(sale.amount)}</p>
                {getStatusBadge(sale.status)}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
