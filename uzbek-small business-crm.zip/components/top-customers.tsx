import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import type { Customer } from "@/lib/types"

interface TopCustomersProps {
  customers: Customer[]
}

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("uz-UZ").format(amount) + " so'm"
}

function getInitials(name: string): string {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2)
}

export function TopCustomers({ customers }: TopCustomersProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Eng yaxshi mijozlar</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {customers.map((customer, index) => (
            <div key={customer.id} className="flex items-center gap-4 rounded-lg border border-border p-4">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted text-sm font-semibold text-muted-foreground">
                {index + 1}
              </div>
              <Avatar className="h-10 w-10">
                <AvatarFallback className="bg-primary/10 text-primary">{getInitials(customer.name)}</AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-1">
                <p className="text-sm font-medium text-card-foreground">{customer.name}</p>
                <p className="text-xs text-muted-foreground">{customer.company || customer.phone}</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-semibold text-card-foreground">{formatCurrency(customer.totalPurchases)}</p>
                <p className="text-xs text-muted-foreground">Jami sotuvlar</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
